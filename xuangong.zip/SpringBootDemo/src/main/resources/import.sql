insert into student (id,name) values ('1','oliver');
insert into student (id,name) values ('2','xuan');
insert into student (id,name) values ('3','gong');
insert into student (id,name) values ('4','james');
insert into student (id,name) values ('5','leborn');

insert into course (studentid,name) values ('1','math');
insert into course (studentid,name) values ('1','chemical');
insert into course (studentid,name) values ('2','math');
insert into course (studentid,name) values ('2','math');
insert into course (studentid,name) values ('4','math');
insert into course (studentid,name) values ('5','math');