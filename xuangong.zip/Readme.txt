front-end: based on ReactJS
1. At the root of the project run `$ npm install`
2. `$ npm start` or `$ yarn start`
3. Your front-end server is up and running.

back-end: based on Spring boot
1. At the root of the project run `$ mvn install`
2. run SpringBootDemo main class
3. Your back-end server is up and running.
